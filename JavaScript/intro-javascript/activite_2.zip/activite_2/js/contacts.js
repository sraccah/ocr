/* 
Activité : gestion des contacts
*/

// TODO : complétez le programme

// Message de bienvenue
console.log("Bienvenue dans le gestionnaire de contacts.");

// Objet contact contenant nom et prénom
var Contact = {
	init: function(firstname, lastname) {
		this.prenom = firstname;
		this.nom = lastname;
	},
	list: function() {
		var line = "[Prénom] " + this.prenom + " [Nom] " + this.nom
		return line;
	}
};

// Tableau de contacts
var contacts = [];

// Enregistrement de Carole et Mélodie
var carole = Object.create(Contact);
carole.init("Carole", "Lévisse");
var melodie = Object.create(Contact);
melodie.init("Mélodie", "Nelsonne");

// Ajout de Carole et Mélodie au tableau
contacts.push(carole);
contacts.push(melodie);

// Buffer de commande de l'utilisateur
var saisie = 0;

// Tant que l'utilisateur n'entre pas 3 (quitter) on boucle le programme
while (saisie != 3) {
	// On affiche les commandes disponibles
	console.log("\nLes commandes sont :");
	console.log("1 - Lister les contacts");
	console.log("2 - Ajouter un nouveau contact");
	console.log("3 - Quitter le gestionnaire de contacts");
	// On demande quelle commande executer
	saisie = prompt("Entrez une commande : ");
	// Si c'est la commande 1 (lister) on demande la liste de contacts
	if (saisie == 1) {
		console.log("\nVoici la liste de contact : ");
		contacts.forEach(function(contact) {
			console.log(contact.list());
		});
	}
	// Si c'est la commande 2 (ajouter) on créer le nouveau contact du tableau
	if (saisie == 2) {
		var lastname = prompt("Entrez un nom : ");
		var firstname = prompt("Entrez un prénom : ");
		var nouveau = Object.create(Contact);
		nouveau.init(firstname, lastname);
		contacts.push(nouveau);
	}
}

// Message de fin car l'utilisateur a entré la commande 3 (quitter)
console.log("\nVous avez bien quitté le programme.");