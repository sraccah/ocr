/* 
Activité : jeu de devinette
*/

// NE PAS MODIFIER OU SUPPRIMER LES LIGNES CI-DESSOUS
// COMPLETEZ LE PROGRAMME UNIQUEMENT APRES LE TODO

console.log("Bienvenue dans ce jeu de devinette !");

// Cette ligne génère aléatoirement un nombre entre 1 et 100
var solution = Math.floor(Math.random() * 100) + 1;

// Décommentez temporairement cette ligne pour mieux vérifier le programme
//console.log("(La solution est " + solution + ")");

// TODO : complétez le programme

var i = 0;

while (i != 6 && solution != saisie) {
	var saisie = prompt("Devinez le nombre mystère : ");
	if (saisie > solution)
		console.log(saisie + " est trop grand")
	if (saisie < solution)
		console.log(saisie + " est trop petit")
	if (saisie == solution) {
		console.log("Bravo vous avez trouvé le nombre mystère : " + solution);
		console.log("Et vous l'avez trouvé en " + (i + 1) + " coups !");
	}
	i++;
}

if (i == 6 && solution != saisie) {
	console.log("Dommage ! Le nombre mystère était : " + solution);
}
